git ls-files --others --ignored --exclude-from=.git/info/exclude

