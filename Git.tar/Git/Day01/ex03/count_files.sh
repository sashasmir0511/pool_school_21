find . -type f -o -type d | wc -l
