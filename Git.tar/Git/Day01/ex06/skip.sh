#!/bin/sh

ls -l | sed 'n;d'
