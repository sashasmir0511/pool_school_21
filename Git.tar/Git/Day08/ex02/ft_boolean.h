#ifndef FT_BOOLEAN_H
# define FT_BOOLEAN_H



#endif
