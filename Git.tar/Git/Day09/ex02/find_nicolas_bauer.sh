more $1 | grep -i "bauer\t" | grep -i "Nicolas" | wc -l | cut -b 7-24 | sed "s/ //" 
